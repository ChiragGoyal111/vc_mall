import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * bookticket.java
 *
 * Created on Nov 10, 2010, 12:12:30 AM
 */

/**
 *
 * @author Administrator
 */
public class bookticket extends javax.swing.JFrame {
    static int vvv;
    static String pas;
    static int j;


    int x=0,y=100;

    /** Creates new form bookticket */
    public bookticket() {
        initComponents();
    }

 public void paint(Graphics g)
    {
      super.paint(g);
      Graphics2D g2=(Graphics2D)g;
      Font font=new Font("Chiller",Font.BOLD+Font.PLAIN,42);
      g2.setFont(font);
      g2.setColor(Color.green);
      g2.drawString("V.C. MALL", x, y);

try{
    Thread.sleep(70);

}
        catch(Exception e)
        {}x+=3;
      if(x>this.getWidth())
      {
          x=0;
      }
      repaint();
    }


   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        cash = new javax.swing.JRadioButton();
        american = new javax.swing.JRadioButton();
        visha = new javax.swing.JRadioButton();
        mcard = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        Stails = new javax.swing.JRadioButton();
        circle = new javax.swing.JRadioButton();
        ucircle = new javax.swing.JRadioButton();
        Box = new javax.swing.JRadioButton();
        msg1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pass = new javax.swing.JTextField();
        b = new javax.swing.JButton();
        msg = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        day = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        m = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        kkk = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tf1 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("THEATRE BOOKING");

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Footlight MT Light", 3, 48));
        jLabel2.setForeground(new java.awt.Color(153, 0, 153));
        jLabel2.setText("THEATRE BOOKING");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(230, 0, 445, 45);

        jPanel3.setBackground(new java.awt.Color(0, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Payment Method", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 204))); // NOI18N

        cash.setText("Cash");

        american.setText("American Express");

        visha.setText("Visha");

        mcard.setText("Master Card");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cash)
                    .addComponent(american))
                .addGap(70, 70, 70)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(visha)
                    .addComponent(mcard))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cash)
                    .addComponent(visha))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mcard)
                    .addComponent(american))
                .addGap(30, 30, 30))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(380, 90, 320, 180);

        jSeparator1.setBackground(new java.awt.Color(153, 0, 0));
        jPanel1.add(jSeparator1);
        jSeparator1.setBounds(10, 48, 900, 2);

        jPanel2.setBackground(new java.awt.Color(0, 255, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Seat type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(204, 0, 204))); // NOI18N
        jPanel2.setForeground(new java.awt.Color(51, 255, 0));

        Stails.setText("Stails");
        Stails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StailsActionPerformed(evt);
            }
        });

        circle.setText("Circle");
        circle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                circleActionPerformed(evt);
            }
        });

        ucircle.setText("Upper circle");
        ucircle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ucircleActionPerformed(evt);
            }
        });

        Box.setText("Box");
        Box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BoxActionPerformed(evt);
            }
        });

        msg1.setFont(new java.awt.Font("Tahoma", 3, 18));
        msg1.setForeground(new java.awt.Color(0, 0, 204));
        msg1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Stails)
                            .addComponent(ucircle))
                        .addGap(79, 79, 79)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Box)
                            .addComponent(circle)))
                    .addComponent(msg1, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Stails)
                    .addComponent(circle))
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ucircle)
                    .addComponent(Box))
                .addGap(18, 18, 18)
                .addComponent(msg1, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 80, 319, 185);

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 24));
        jLabel3.setForeground(new java.awt.Color(255, 0, 51));
        jLabel3.setText("Enter password:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(450, 290, 210, 30);

        pass.setFont(new java.awt.Font("Tahoma", 3, 18));
        pass.setForeground(new java.awt.Color(0, 255, 204));
        jPanel1.add(pass);
        pass.setBounds(650, 290, 260, 30);

        b.setFont(new java.awt.Font("Tahoma", 3, 18));
        b.setText("Book Seats");
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActionPerformed(evt);
            }
        });
        jPanel1.add(b);
        b.setBounds(100, 400, 180, 40);

        msg.setFont(new java.awt.Font("Tahoma", 3, 18));
        msg.setForeground(new java.awt.Color(0, 204, 204));
        msg.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(msg);
        msg.setBounds(310, 390, 600, 60);

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 36));
        jLabel4.setForeground(new java.awt.Color(204, 0, 51));
        jLabel4.setText("Date:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(230, 330, 130, 40);

        day.setFont(new java.awt.Font("Tahoma", 3, 18));
        jPanel1.add(day);
        day.setBounds(360, 340, 70, 40);

        jLabel5.setFont(new java.awt.Font("Tahoma", 3, 36));
        jLabel5.setText("/");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(440, 340, 30, 40);

        m.setFont(new java.awt.Font("Tahoma", 3, 18));
        jPanel1.add(m);
        m.setBounds(480, 340, 70, 40);

        jLabel6.setFont(new java.awt.Font("Tahoma", 3, 36));
        jLabel6.setText("/");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(560, 340, 40, 40);

        kkk.setFont(new java.awt.Font("Tahoma", 3, 18));
        jPanel1.add(kkk);
        kkk.setBounds(600, 340, 120, 40);

        jLabel7.setFont(new java.awt.Font("Tahoma", 3, 24));
        jLabel7.setForeground(new java.awt.Color(255, 0, 51));
        jLabel7.setText("Number of seats required:");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(10, 290, 320, 30);

        tf1.setFont(new java.awt.Font("Tahoma", 3, 18));
        tf1.setForeground(new java.awt.Color(0, 255, 204));
        jPanel1.add(tf1);
        tf1.setBounds(330, 290, 120, 30);

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18));
        jButton4.setForeground(new java.awt.Color(255, 0, 0));
        jButton4.setText("Home ");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(810, 0, 110, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\vcmallpics\\h1.jpg")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 920, 470);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 916, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 464, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void StailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StailsActionPerformed
        if(Stails.isSelected()==true)
            msg1.setText("Price per seat"+"="+"Rs. 625/-");        // TODO add your handling code here:
}//GEN-LAST:event_StailsActionPerformed

    private void circleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_circleActionPerformed
        if(circle.isSelected()==true)
            msg1.setText("Price per seat"+"="+"Rs. 750/-");        // TODO add your handling code here:
}//GEN-LAST:event_circleActionPerformed

    private void ucircleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ucircleActionPerformed
        if(ucircle.isSelected()==true)
            msg1.setText("Price per seat"+"="+"Rs. 850/-");        // TODO add your handling code here:
}//GEN-LAST:event_ucircleActionPerformed

    private void BoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BoxActionPerformed
        if(Box.isSelected()==true)
            msg1.setText("Price per seat"+"="+"Rs. 1000/-");        // TODO add your handling code here:
}//GEN-LAST:event_BoxActionPerformed

    private void bActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActionPerformed
     pas=new String(pass.getText());
        int d=Integer.parseInt(day.getText());
        int mo=Integer.parseInt(m.getText());
        int ye=Integer.parseInt(kkk.getText());
        int i;
                j=0;
        i=Integer.parseInt(tf1.getText());
        if(i<1)
            msg.setText("INVALID INPUT");

        if(Stails.isSelected()==true)
            j=i*625;
        if(circle.isSelected()==true)
            j=i*750;
        if(ucircle.isSelected()==true)
            j=i*850;
        if(Box.isSelected()==true)
            j=i*1000;

        if(cash.isSelected()==true)
            msg.setText("cash payment of Rs."+j+"for movie on"+d+"/"+mo+"/"+ye);

        if(visha.isSelected()==true)
            msg.setText("visha payment of Rs."+j);

        if(american.isSelected()==true)
            msg.setText("American express payment of Rs."+j);

        if(mcard.isSelected()==true)
            msg.setText("Master card payment of Rs."+j);
          try
         {
               Class.forName("java.sql.DriverManager");
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/mall","root","dmps");
            Statement stmt=(Statement)con.createStatement();
           String query="select * from account where Password='"+pas+"';";
            ResultSet rs=stmt.executeQuery(query);
 if(rs.next())
            {

                  vvv=rs.getInt("coins");

 }

         }

catch(Exception e)
     {
             JOptionPane.showMessageDialog(this,e.getMessage());
     }
          JOptionPane.showMessageDialog(this,"SUCCESSFULLY BOOKED");



    }//GEN-LAST:event_bActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        new home_page().setVisible(true);
        this.setVisible(false);
        int t=vvv-j;

         try
         {
               Class.forName("java.sql.DriverManager");
            Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/mall","root","dmps");
            Statement stmt=(Statement)con.createStatement();
            String query="update account SET coins ='"+t+"'where password='"+pas+"';";
            int rs=stmt.executeUpdate(query);

 


         }

catch(Exception e)
     {
             JOptionPane.showMessageDialog(this,e.getMessage());
     }// TODO add your handling code here:
}//GEN-LAST:event_jButton4ActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new bookticket().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Box;
    private javax.swing.JRadioButton Stails;
    private javax.swing.JRadioButton american;
    private javax.swing.JButton b;
    private javax.swing.JRadioButton cash;
    private javax.swing.JRadioButton circle;
    private javax.swing.JTextField day;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField kkk;
    private javax.swing.JTextField m;
    private javax.swing.JRadioButton mcard;
    private javax.swing.JLabel msg;
    private javax.swing.JLabel msg1;
    private javax.swing.JTextField pass;
    private javax.swing.JTextField tf1;
    private javax.swing.JRadioButton ucircle;
    private javax.swing.JRadioButton visha;
    // End of variables declaration//GEN-END:variables

}
